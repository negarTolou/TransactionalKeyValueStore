//
//  KeyValueStoreApp.swift
//  KeyValueStore
//
//  Created by Negar Tolou on 19.03.23.
//

import SwiftUI

@main
struct KeyValueStoreApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
